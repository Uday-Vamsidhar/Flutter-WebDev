//to connect to database

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: const MyStatefulWidget(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(10),
        child: ListView(
          children: <Widget>[
            Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: const Text(
                  'Welcome To PandemiControl',
                  style: TextStyle(
                    color: Colors.blue,
                    fontWeight: FontWeight.w500,
                    fontSize: 30,
                  ),
                  textAlign: TextAlign.center,
                )),
            Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: const Text(
                  'Sign in',
                  style: TextStyle(fontSize: 20),
                )),
            Container(
              padding: const EdgeInsets.all(10),
              child: TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'User Name',
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: TextField(
                obscureText: true,
                controller: passwordController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Password',
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                //forgot password screen
                gotoforgot(context);
              },
              child: const Text(
                'Forgot Password',
                style: TextStyle(fontSize: 15),
              ),
            ),
            Container(
                height: 75,
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                child: ElevatedButton(
                  child: const Text(
                    'Login',
                    style: TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    print(nameController.text);
                    print(passwordController.text);
                    gototester(context);
                  },
                )),
            Row(children: <Widget>[
              const Text(
                'Do not have an account?',
                style: TextStyle(fontSize: 15),
              ),
              TextButton(
                child: const Text(
                  'Sign Up',
                  style: TextStyle(fontSize: 20),
                ),
                onPressed: () {
                  //signup screen
                  gotosignup(context);
                },
              )
            ], mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center),
          ],
        ));
  }
}

void gotosignup(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => SignUp()));
}

class SignUp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String __title = "PandemiControl";
    return MaterialApp(
      title: __title,
      home: Scaffold(
        appBar: AppBar(title: Text(__title)),
        body: FsignUp(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class FsignUp extends SignUp {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListView(children: <Widget>[
        Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(10),
          child: const Text(
            'Welcome To PandemiControl',
            style: TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
              fontSize: 30,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Sign Up',
              style: TextStyle(fontSize: 20),
            )),
        Container(
          padding: const EdgeInsets.all(10),
          child: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Email ID',
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(10),
          child: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'User Name',
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
          child: TextField(
            obscureText: true,
            controller: passwordController,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Password',
            ),
          ),
        ),
        Container(
            height: 100,
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: ElevatedButton(
              child: const Text('Join', style: TextStyle(fontSize: 25)),
              onPressed: () {
                gototester(context);
              },
            )),
        TextButton(
          onPressed: () {
            gotologin(context);
          },
          child: const Text(
            'Sign In',
            style: TextStyle(fontSize: 20),
          ),
        ),
      ]),
    );
  }
}

void gotologin(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => MyApp()));
}

void gotoforgot(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Forgot()));
}

class Forgot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String __title = "PandemiControl";
    return MaterialApp(
      title: __title,
      home: Scaffold(
        appBar: AppBar(title: Text(__title)),
        body: Fforgot(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class Fforgot extends Forgot {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListView(children: <Widget>[
        Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(10),
          child: const Text(
            'Welcome To PandemiControl',
            style: TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
              fontSize: 30,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Forgot Password',
              style: TextStyle(fontSize: 20),
            )),
        Container(
          padding: const EdgeInsets.all(10),
          child: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Email ID',
            ),
          ),
        ),
        Container(
            height: 70,
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: ElevatedButton(
              child: const Text('Reset Password', style: TextStyle(fontSize: 25)),
              onPressed: () {
                //send mail
              },
            )),
        Row(
          children: <Widget>[
            const Text(
              'Know the password?',
              style: TextStyle(fontSize: 15),
            ),
            TextButton(
              child: const Text(
                'Sign In',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                //signup screen
                gotologin(context);
              },
            )
          ],
          mainAxisAlignment: MainAxisAlignment.center,
        ),
        Row(
          children: <Widget>[
            const Text(
              'Do not have an account?',
              style: TextStyle(fontSize: 15),
            ),
            TextButton(
              child: const Text(
                'Sign Up',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                //signup screen
                gotosignup(context);
              },
            )
          ],
          mainAxisAlignment: MainAxisAlignment.center,
        ),
      ]),
    );
  }
}

class Welcome extends StatelessWidget {
  const Welcome({Key? key}) : super(key: key);

  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: Welcomeit(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class Welcomeit extends Welcome {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListView(
        children: <Widget>[
          Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(10),
              child: const Text(
                'Status & Eligibility',
                style: TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.w500,
                  fontSize: 25,
                ),
                textAlign: TextAlign.center,
              )),
          Row(children: <Widget>[
            const Text(
              'Check your status?',
              style: TextStyle(fontSize: 15),
            ),
            TextButton(
              child: const Text(
                'Check',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                //goto checker
              },
            ),
            Divider(
              color: Colors.blue[600],
            )
          ], mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center),
          Row(children: <Widget>[
            const Text(
              'Check your community status?',
              style: TextStyle(fontSize: 15),
            ),
            TextButton(
              child: const Text(
                'Check',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                //goto checker
              },
            ),
            Divider(
              color: Colors.blue[600],
            )
          ], mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center),
          Row(children: <Widget>[
            const Text(
              'Check your aligibility?',
              style: TextStyle(fontSize: 15),
            ),
            TextButton(
              child: const Text(
                'Check',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                //goto checker
              },
            ),
          ], mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center),
          Container(
            height: 75,
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: Align(
              alignment: Alignment.center,
              child: ElevatedButton(
                child: const Text('Home', style: TextStyle(fontSize: 25)),
                onPressed: () {
                  gototester(context);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

void gotohome(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Welcome()));
}

void gototester(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Tester()));
}

class Tester extends StatelessWidget {
  const Tester({Key? key}) : super(key: key);

  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: Testit(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class Testit extends Tester {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListView(children: <Widget>[
        Container(
          height: 100,
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: ElevatedButton(
            child: const Text('Status', style: TextStyle(fontSize: 25)),
            onPressed: () {
              gotohome(context);
            },
          ),
        ),
        Container(
          height: 100,
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: ElevatedButton(
            child: const Text('Manual Test', style: TextStyle(fontSize: 25)),
            onPressed: () {
              gotomant(context);
            },
          ),
        ),
        Container(
          height: 100,
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: ElevatedButton(
            child: const Text('Protocols', style: TextStyle(fontSize: 25)),
            onPressed: () {
              gotoprot(context);
            },
          ),
        ),
      ]),
    );
  }
}

class Protocols extends StatelessWidget {
  const Protocols({Key? key}) : super(key: key);

  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: Protsit(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class Protsit extends Protocols {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: ListView(children: <Widget>[
        Row(children: <Widget>[
          const Text(
            'Maintain atleast 6 feet distance from others.',
            style: TextStyle(fontSize: 15),
          ),
        ]),
        Row(children: <Widget>[
          const Text(
            'Wear mask at all times.',
            style: TextStyle(fontSize: 15),
          ),
        ]),
        Container(
          height: 75,
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: Align(
            alignment: Alignment.center,
            child: ElevatedButton(
              child: const Text('Home', style: TextStyle(fontSize: 25)),
              onPressed: () {
                gototester(context);
              },
            ),
          ),
        ),
      ]),
    );
  }
}

class ManTest extends StatelessWidget {
  const ManTest({Key? key}) : super(key: key);

  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: Mantestit(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

void gotomant(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => ManTest()));
}

void gotoprot(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Protocols()));
}

//check from here

class Mantestit extends ManTest {
  @override
  var cntyes = 0, cntno = 0;
  Widget build(BuildContext context) {
    return AlertDialog(title: new Text('Manual Test'), backgroundColor: Colors.cyan[100], shape: RoundedRectangleBorder(borderRadius: new BorderRadius.circular(15)), actions: <Widget>[
      new FlatButton(
        child: new Text('Yes'),
        textColor: Colors.greenAccent,
        onPressed: () {
          cntyes += 1;
        },
      ),
      new FlatButton(
        child: Text('No'),
        textColor: Colors.redAccent,
        onPressed: () {
          cntno += 1;
        },
      ),
      new ElevatedButton(
        child: const Text('Check Results', style: TextStyle(fontSize: 25)),
        onPressed: () {
          gotoresult(context);
        },
      ),
    ]);
  }
}

void gotoresult(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Results()));
}

class Results extends StatelessWidget {
  static const String _title = 'PandemiControl';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: DispRes(),
        backgroundColor: Colors.cyan[100],
      ),
    );
  }
}

class DispRes extends Results {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Results"),
      ),
      body: new Center(
        child: new Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
          new Text("Number of 'Yes': ${Mantestit().cntyes}"),
        ]),
      ),
    );
  }
}
