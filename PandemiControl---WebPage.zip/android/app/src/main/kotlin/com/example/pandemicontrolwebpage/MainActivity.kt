package com.example.pandemicontrolwebpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
